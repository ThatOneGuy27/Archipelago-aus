How to get started:

- Download all the fonts in the "newfonts" folder
- Acquire Game Maker 8.1 (available on archive.org as of this writing)
- Open AnUntitledStory-Archipelago.gm81 in Game Maker

To test the game after making changes, you'll need to:
- Press the "Create a stand-alone executable for your game" button in the top left
- Ensure the .exe file has the following in its folder (these are all included in the normal release):
  - a "BGs" folder with background images
  - ArchipelagoConnectionInfo.ini
  - gm-apclientpp.dll
  - UntitledRecords
- Launch the game!

Note that this is separate from saving your changes to the .gm81 file, so both need to be done separately.

- Some debug options are available (including arbitrary command execution) by uncommenting the code in obj_player -> Step -> debug. Make sure to comment this out before releasing builds.

- Most Archipelago code is found in Scripts -> ap generic / ap callbacks. Callbacks rely on either the obj_ap_controller object (setup only) or the player being present in the room, both of which call apclient_poll() every frame.

If you have any further questions or anything breaks, contact @thatoneguy27 on discord. Happy modding!

